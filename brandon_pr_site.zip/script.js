function contact() {
  window.location.href = "https://wa.me/237000000000";
}

function pay() {
  FlutterwaveCheckout({
    public_key: "YOUR_PUBLIC_KEY",
    tx_ref: "tx-" + Date.now(),
    amount: 5000,
    currency: "XAF",
    payment_options: "mobilemoney",
    customer: {
      email: "client@email.com",
      name: "Client"
    },
    callback: function(response) {
      alert("Paiement réussi !");
    }
  });
}
